function object=PASemptyobject
  object.label='';
  object.orglabel='';
  object.bbox=[];
  object.polygon=[];
  object.mask='';
  object.class='';
  object.view='';
  object.truncated=false;
  object.difficult=false;
return